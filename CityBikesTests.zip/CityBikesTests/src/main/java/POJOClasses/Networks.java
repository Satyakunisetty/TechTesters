package POJOClasses;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Networks
{
	private String name;
	
	
	//private String[] company;
	
	//[void JsonConverter(typeof(SingleOrArrayConverter<String>))]
//	private List<String> company;
	private Object company;
	
	
	private Location location;
	private License license;
	private String gbfs_href;
	private String href;
	private String id;
	private String source;

	public String getName ()
	{
		return name;
	}
	
	public void setName (String name)
	{
		this.name = name;
	}
	
	public Object getCompany ()
	{
		return company;
	}
	
	
	
	public void setCompany (Object company)
	{
		this.company = company;
	}
	
	public Location getLocation ()
	{
		return location;
	}
	
	public void setLocation (Location location)
	{
		this.location = location;
	}
		
	public License getLicense ()
	{
		return license;
	}
	
	public void setLicense (License license)
	{
		this.license = license;
	}	
	
	public String getHref ()
	{
		return href;
	}
	
	public void setHref (String href)
	{
		this.href = href;
	}
	
	public String getGbfshref ()
	{
		return gbfs_href;
	}
	
	public void setGbfshref (String gbfs_href)
	{
		this.gbfs_href = gbfs_href;
	}
			
	public String getId ()
	{
		return id;
	}
	
	public void setId (String id)
	{
		this.id = id;
	}
	
	public String getSource ()
	{
		return source;
	}
	
	public void setSource (String source)
	{
		this.source = source;
	}
		
	@Override
	public String toString()
	{
		return "ClassPojo [name = "+name+", company = "+company+", location = "+location+", href = "+href+", id = "+id+"]";
	}
}