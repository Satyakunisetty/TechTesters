package POJOClasses;

public class SingleOrArrayConverter<T> 
{


}
