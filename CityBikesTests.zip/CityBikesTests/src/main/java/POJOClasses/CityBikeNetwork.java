package POJOClasses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)

public class CityBikeNetwork {
	
	
	  private Networks[] networks;

	    public Networks[] getNetworks ()
	    {
	        return networks;
	    }

	    public void setNetworks (Networks[] networks)
	    {
	        this.networks = networks;
	    }

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [networks = "+networks+"]";
	    }
}
