package utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import java.util.Properties;

import com.fasterxml.jackson.databind.ObjectMapper;

public class GenericMethods {
	
	ObjectMapper mapper;
	Properties prop;
	HttpResponse<String> response;
	HttpClient client;
	HttpRequest request;
	
	private String globalProperties = "src/test/java/resources/global.properties";
	
	public GenericMethods() 
	{
		mapper = new ObjectMapper();
		prop = new Properties();	
	}
	
	
	public String confiureBaseURL() throws IOException, FileNotFoundException
	{
		String URL = null;
		FileInputStream fis = new FileInputStream(globalProperties);
		prop.load(fis);	
		URL = prop.getProperty("baseURL");		
		return URL;
	}
	
	
	public HttpResponse<String> callGetAPI(String baseURL) throws IOException, InterruptedException
	{
		client = HttpClient.newHttpClient();	       
		request = HttpRequest.newBuilder()
				  .uri(URI.create(baseURL))
				  .build();
	    response =  client.send(request, HttpResponse.BodyHandlers.ofString());				
		return response;		
	}
	
}
