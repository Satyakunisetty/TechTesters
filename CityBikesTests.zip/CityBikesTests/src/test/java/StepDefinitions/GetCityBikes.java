package StepDefinitions;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Properties;

import org.apache.http.HttpEntity;
import org.junit.Assert;


import java.io.*;


import com.fasterxml.jackson.databind.ObjectMapper;


import POJOClasses.CityBikeNetwork;
import POJOClasses.Location;
import POJOClasses.Networks;
import io.cucumber.java.en.*;
import utils.GenericMethods;

public class GetCityBikes 
{
	HttpClient client;
	HttpRequest request;
	HttpResponse<String> response;
	ObjectMapper mapper;
	GenericMethods reuseMethods;
	CityBikeNetwork cityBikeNetwork;	
	Properties prop;
	
	Networks[] resultValues;
	Location locationValue;
	
	public String baseURL=null;	
		
	public GetCityBikes()
	{
		
		mapper = new ObjectMapper();
		prop = new Properties();
		reuseMethods = new GenericMethods();
	}

	@Given("User configure the base URL of CityBikeNetwork API")
	public void user_configure_the_base_url_of_city_bike_network_api() throws FileNotFoundException, IOException 
	{			
		baseURL = reuseMethods.confiureBaseURL();
		System.out.println(baseURL);
	}

	@When("user calls CityBikeNetwork using GET method")
	public void user_calls_city_bike_network_using_get_method() throws IOException, InterruptedException 
	{
		response = reuseMethods.callGetAPI(baseURL);		
		cityBikeNetwork = mapper.readValue(response.body(), CityBikeNetwork.class);
		Assert.assertNotNull(cityBikeNetwork);			
	}

	@Then("user validates location section attributes like {string},{string},{string} based on {string}")
	public void user_validates_location_section_attributes(String country, String latitude, String longitude, String city) 
	{
			
		resultValues = cityBikeNetwork.getNetworks();
		
		for (int i=0;i<resultValues.length;i++)
		{
			locationValue = resultValues[i].getLocation();			
			
			if(locationValue.getCity().toLowerCase().equals(city.toLowerCase()))
			{
				
				Object[] expectedValues = {country,latitude,longitude};				
				System.out.println("expected values : " + country + latitude + longitude );
				
				Object [] actualValues = {locationValue.getCountry(),locationValue.getLatitude(),locationValue.getLongitude()};				
				System.out.println("actual values : " + locationValue.getCountry() + locationValue.getLatitude() + locationValue.getLongitude() );
				
				Assert.assertArrayEquals("validate Location Section values",expectedValues,actualValues);
			}
			
		}		
	}
	
	@Then("user validates company values {string} based on {string}")
	public void user_validates_company_values_based_on(String company_Values, String name) 
	{
		resultValues = cityBikeNetwork.getNetworks();
		
		for (int i=0;i<resultValues.length;i++)
		{
			String networkName = resultValues[i].getName();
			
			if(networkName.toLowerCase().equals(name.toLowerCase()))
			{
				//Convert feature file company values to ArrayList 
				ArrayList<String> expectedValues =  new ArrayList<String>();
				
				String [] tempvals = company_Values.split(":");
				for(int j=0; j<tempvals.length;j++)
					expectedValues.add(tempvals[j]);
				
				Collections.sort(expectedValues);
				
				//Capture API response values.
				ArrayList<String> actualValues =  new ArrayList<String>();				 
				if(resultValues[i].getCompany() instanceof String)	
				{
					String val = (String) resultValues[i].getCompany();					
					actualValues.add(val);						
				}				
				else if(resultValues[i].getCompany() instanceof java.util.ArrayList)					
					actualValues = (ArrayList<String>) resultValues[i].getCompany();					
				
				Collections.sort(actualValues);				
				Assert.assertTrue("Expected and Actual Company values", expectedValues.equals(actualValues));
			}
		}
		
		
	}
	
	
	@Then("user validate {string} value from network based on {string}")
	public void user_validate_source_value_from_network(String source, String name) 
	{
		
		resultValues = cityBikeNetwork.getNetworks();
		
		for (int i=0;i<resultValues.length;i++)
		{
			String networkName = resultValues[i].getName();
			
			if(networkName.toLowerCase().equals(name.toLowerCase()))
				Assert.assertTrue(resultValues[i].getSource().contains(source));
		}
	}
	
	
	
	
	
	
}







//System.out.println(resultValues[97].getCompany() instanceof String);

//Class arrayClass = resultValues[98].getCompany().getClass();

//System.out.println(resultValues[98].getCompany() instanceof java.util.ArrayList);

//System.out.println(arrayClass);
//System.out.println(arrayClass.isArray());





