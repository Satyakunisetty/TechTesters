package cucumber.Options;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions( features = "src/test/java/Features/CityBikes.feature",  tags= "@CityBikeNetwork",
				  glue= {"StepDefinitions"},
				 plugin= "json:target/jsonReports/cucumber-reports.json"			 
				)


public class TestRunner {
	
	

}
